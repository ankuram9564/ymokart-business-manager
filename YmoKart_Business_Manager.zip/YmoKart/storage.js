/* YmoKart - Storage Module (Local Storage Database) */

const Storage = {
    KEYS: {
        PRODUCTS: 'ymokart_products',
        SETTINGS: 'ymokart_settings',
        BACKUP: 'ymokart_backup'
    },

    // Initialize default settings
    init() {
        if (!localStorage.getItem(this.KEYS.SETTINGS)) {
            const defaultSettings = {
                theme: 'dark',
                currency: 'INR',
                businessName: 'YmoKart Business'
            };
            this.setSettings(defaultSettings);
        }
        return this;
    },

    // Products CRUD
    getProducts() {
        try {
            const data = localStorage.getItem(this.KEYS.PRODUCTS);
            return data ? JSON.parse(data) : [];
        } catch (e) {
            console.error('Error reading products:', e);
            return [];
        }
    },

    saveProducts(products) {
        try {
            localStorage.setItem(this.KEYS.PRODUCTS, JSON.stringify(products));
            return true;
        } catch (e) {
            console.error('Error saving products:', e);
            return false;
        }
    },

    addProduct(product) {
        const products = this.getProducts();
        product.id = this.generateId();
        product.createdAt = new Date().toISOString();
        products.push(product);
        this.saveProducts(products);
        return product;
    },

    updateProduct(id, updatedData) {
        const products = this.getProducts();
        const index = products.findIndex(p => p.id === id);
        if (index !== -1) {
            products[index] = { ...products[index], ...updatedData, updatedAt: new Date().toISOString() };
            this.saveProducts(products);
            return products[index];
        }
        return null;
    },

    deleteProduct(id) {
        const products = this.getProducts();
        const filtered = products.filter(p => p.id !== id);
        this.saveProducts(filtered);
        return filtered.length !== products.length;
    },

    findProduct(id) {
        const products = this.getProducts();
        return products.find(p => p.id === id) || null;
    },

    searchProducts(query) {
        const products = this.getProducts();
        const q = query.toLowerCase().trim();
        if (!q) return products;
        return products.filter(p =>
            p.name?.toLowerCase().includes(q) ||
            p.artNumber?.toLowerCase().includes(q) ||
            p.brand?.toLowerCase().includes(q) ||
            p.category?.toLowerCase().includes(q) ||
            p.color?.toLowerCase().includes(q)
        );
    },

    getProductsByCategory(category) {
        const products = this.getProducts();
        return products.filter(p => p.category === category);
    },

    // Settings
    getSettings() {
        try {
            const data = localStorage.getItem(this.KEYS.SETTINGS);
            return data ? JSON.parse(data) : {};
        } catch (e) {
            console.error('Error reading settings:', e);
            return {};
        }
    },

    setSettings(settings) {
        try {
            localStorage.setItem(this.KEYS.SETTINGS, JSON.stringify(settings));
            return true;
        } catch (e) {
            console.error('Error saving settings:', e);
            return false;
        }
    },

    updateSettings(newSettings) {
        const settings = this.getSettings();
        const merged = { ...settings, ...newSettings };
        this.setSettings(merged);
        return merged;
    },

    // Backup & Restore
    createBackup() {
        const backup = {
            version: '1.0',
            timestamp: new Date().toISOString(),
            products: this.getProducts(),
            settings: this.getSettings()
        };
        return JSON.stringify(backup, null, 2);
    },

    restoreBackup(backupJson) {
        try {
            const backup = JSON.parse(backupJson);
            if (backup.products) {
                this.saveProducts(backup.products);
            }
            if (backup.settings) {
                this.setSettings(backup.settings);
            }
            return true;
        } catch (e) {
            console.error('Error restoring backup:', e);
            return false;
        }
    },

    downloadBackup() {
        const backup = this.createBackup();
        const blob = new Blob([backup], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `ymokart_backup_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    },

    clearAllData() {
        localStorage.removeItem(this.KEYS.PRODUCTS);
        localStorage.removeItem(this.KEYS.SETTINGS);
        return true;
    },

    // Statistics
    getStats() {
        const products = this.getProducts();
        const stats = {
            totalProducts: products.length,
            totalStock: 0,
            totalMRP: 0,
            totalDealerValue: 0,
            categories: {},
            brands: {},
            lowStock: []
        };

        products.forEach(p => {
            const stock = parseInt(p.stock) || 0;
            const mrp = parseFloat(p.mrp) || 0;
            const dealerPrice = parseFloat(p.dealerPrice) || 0;

            stats.totalStock += stock;
            stats.totalMRP += mrp * stock;
            stats.totalDealerValue += dealerPrice * stock;

            if (p.category) {
                stats.categories[p.category] = (stats.categories[p.category] || 0) + 1;
            }
            if (p.brand) {
                stats.brands[p.brand] = (stats.brands[p.brand] || 0) + 1;
            }

            if (stock < 5 && stock > 0) {
                stats.lowStock.push(p);
            }
        });

        return stats;
    },

    // Helper
    generateId() {
        return 'ykm_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
    }
};

// Initialize on load
Storage.init();
